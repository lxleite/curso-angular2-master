/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivaNgforComponent } from './diretiva-ngfor.component';

describe('Component: DiretivaNgfor', () => {
  it('should create an instance', () => {
    let component = new DiretivaNgforComponent();
    expect(component).toBeTruthy();
  });
});

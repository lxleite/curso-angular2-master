/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivasCustomizadasComponent } from './diretivas-customizadas.component';

describe('Component: DiretivasCustomizadas', () => {
  it('should create an instance', () => {
    let component = new DiretivasCustomizadasComponent();
    expect(component).toBeTruthy();
  });
});

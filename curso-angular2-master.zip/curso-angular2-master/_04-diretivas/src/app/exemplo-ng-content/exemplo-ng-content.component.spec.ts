/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ExemploNgContentComponent } from './exemplo-ng-content.component';

describe('Component: ExemploNgContent', () => {
  it('should create an instance', () => {
    let component = new ExemploNgContentComponent();
    expect(component).toBeTruthy();
  });
});

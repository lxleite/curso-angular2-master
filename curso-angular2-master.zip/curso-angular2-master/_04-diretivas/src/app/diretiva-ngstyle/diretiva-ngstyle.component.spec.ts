/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivaNgstyleComponent } from './diretiva-ngstyle.component';

describe('Component: DiretivaNgstyle', () => {
  it('should create an instance', () => {
    let component = new DiretivaNgstyleComponent();
    expect(component).toBeTruthy();
  });
});

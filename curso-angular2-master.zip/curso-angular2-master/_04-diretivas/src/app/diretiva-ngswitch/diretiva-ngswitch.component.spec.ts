/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivaNgswitchComponent } from './diretiva-ngswitch.component';

describe('Component: DiretivaNgswitch', () => {
  it('should create an instance', () => {
    let component = new DiretivaNgswitchComponent();
    expect(component).toBeTruthy();
  });
});

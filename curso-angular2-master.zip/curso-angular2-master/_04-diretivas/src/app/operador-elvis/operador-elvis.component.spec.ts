/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { OperadorElvisComponent } from './operador-elvis.component';

describe('Component: OperadorElvis', () => {
  it('should create an instance', () => {
    let component = new OperadorElvisComponent();
    expect(component).toBeTruthy();
  });
});

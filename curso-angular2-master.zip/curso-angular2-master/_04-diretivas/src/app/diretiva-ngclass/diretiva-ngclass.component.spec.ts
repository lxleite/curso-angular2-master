/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivaNgclassComponent } from './diretiva-ngclass.component';

describe('Component: DiretivaNgclass', () => {
  it('should create an instance', () => {
    let component = new DiretivaNgclassComponent();
    expect(component).toBeTruthy();
  });
});

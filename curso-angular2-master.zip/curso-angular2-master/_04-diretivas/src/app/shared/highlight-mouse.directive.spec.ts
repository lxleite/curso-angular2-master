/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HighlightMouseDirective } from './highlight-mouse.directive';

describe('Directive: HighlightMouse', () => {
  it('should create an instance', () => {
    let directive = new HighlightMouseDirective();
    expect(directive).toBeTruthy();
  });
});

/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HighlightDirective } from './highlight.directive';

describe('Directive: Highlight', () => {
  it('should create an instance', () => {
    let directive = new HighlightDirective();
    expect(directive).toBeTruthy();
  });
});

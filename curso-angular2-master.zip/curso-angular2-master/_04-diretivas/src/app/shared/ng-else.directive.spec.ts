/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { NgElseDirective } from './ng-else.directive';

describe('Directive: NgElse', () => {
  it('should create an instance', () => {
    let directive = new NgElseDirective();
    expect(directive).toBeTruthy();
  });
});

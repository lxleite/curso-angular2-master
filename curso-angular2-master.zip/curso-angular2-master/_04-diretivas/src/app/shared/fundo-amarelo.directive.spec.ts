/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FundoAmareloDirective } from './fundo-amarelo.directive';

describe('Directive: FundoAmarelo', () => {
  it('should create an instance', () => {
    let directive = new FundoAmareloDirective();
    expect(directive).toBeTruthy();
  });
});

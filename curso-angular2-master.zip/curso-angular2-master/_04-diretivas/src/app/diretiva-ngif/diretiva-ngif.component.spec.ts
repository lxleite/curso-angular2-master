/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DiretivaNgifComponent } from './diretiva-ngif.component';

describe('Component: DiretivaNgif', () => {
  it('should create an instance', () => {
    let component = new DiretivaNgifComponent();
    expect(component).toBeTruthy();
  });
});

/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FiltroArrayImpuroPipe } from './filtro-array-impuro.pipe';

describe('Pipe: FiltroArrayImpuro', () => {
  it('create an instance', () => {
    let pipe = new FiltroArrayImpuroPipe();
    expect(pipe).toBeTruthy();
  });
});

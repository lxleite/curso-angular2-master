/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FiltroArrayPipe } from './filtro-array.pipe';

describe('Pipe: FiltroArray', () => {
  it('create an instance', () => {
    let pipe = new FiltroArrayPipe();
    expect(pipe).toBeTruthy();
  });
});

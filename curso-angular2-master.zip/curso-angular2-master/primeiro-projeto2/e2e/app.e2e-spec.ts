import { PrimeiroProjeto2Page } from './app.po';

describe('primeiro-projeto2 App', () => {
  let page: PrimeiroProjeto2Page;

  beforeEach(() => {
    page = new PrimeiroProjeto2Page();
  });

  it('should display welcome message', done => {
    page.navigateTo();
    page.getParagraphText()
      .then(msg => expect(msg).toEqual('Welcome to app!!'))
      .then(done, done.fail);
  });
});
